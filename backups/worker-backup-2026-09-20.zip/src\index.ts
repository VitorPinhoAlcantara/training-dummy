export interface Env {
    DB: D1Database;
    RATE_LIMITER_GET: RateLimit;
    RATE_LIMITER_SUBMIT: RateLimit;
}

interface LeaderboardRow {
    player_name: string;
    damage: number;
}

const CORS_HEADERS: Record<string, string> = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, X-Api-Key",
};

function json(data: unknown, status = 200): Response {
    return new Response(JSON.stringify(data), {
        status,
        headers: { "Content-Type": "application/json", ...CORS_HEADERS },
    });
}

export default {
    async fetch(request: Request, env: Env): Promise<Response> {
        if (request.method === "OPTIONS") {
            return new Response(null, { headers: CORS_HEADERS });
        }

        const url = new URL(request.url);
        const leaderboardMatch = url.pathname.match(/^\/leaderboard\/([^/]+)$/);
        const ip = request.headers.get("CF-Connecting-IP") ?? "unknown";

        if (request.method === "GET" && leaderboardMatch) {
            if (!(await env.RATE_LIMITER_GET.limit({ key: ip })).success) {
                return json({ error: "rate limited, try again shortly" }, 429);
            }
            return handleGetLeaderboard(env, decodeURIComponent(leaderboardMatch[1]));
        }

        if (request.method === "POST" && url.pathname === "/submit") {
            if (!(await env.RATE_LIMITER_SUBMIT.limit({ key: ip })).success) {
                return json({ error: "rate limited, try again shortly" }, 429);
            }
            return handleSubmit(request, env);
        }

        return json({ error: "not found" }, 404);
    },

    async scheduled(_controller: ScheduledController, env: Env): Promise<void> {
        await env.DB.prepare(
            `DELETE FROM leaderboard WHERE modpack_id IN (SELECT id FROM modpacks WHERE auto_reset_weekly = 1)`
        ).run();
    },
} satisfies ExportedHandler<Env>;

interface ModpackRow {
    api_key: string | null;
}

async function getModpack(env: Env, modpackId: string): Promise<ModpackRow | null> {
    return env.DB.prepare("SELECT api_key FROM modpacks WHERE id = ?1").bind(modpackId).first<ModpackRow>();
}

async function handleGetLeaderboard(env: Env, modpackId: string): Promise<Response> {
    if (!modpackId) {
        return json({ error: "missing modpack id" }, 400);
    }
    if (!(await getModpack(env, modpackId))) {
        return json([]);
    }
    const { results } = await env.DB.prepare(
        "SELECT player_name, damage FROM leaderboard WHERE modpack_id = ?1 ORDER BY damage DESC, created_at ASC LIMIT 10"
    ).bind(modpackId).all<LeaderboardRow>();
    return json(results ?? []);
}

interface SnapshotAttribute {
    id?: string;
    base?: number;
}

const EXPECTED_ATTRIBUTE_BASE: Record<string, number> = {
    "minecraft:attack_damage": 1,
    "minecraft:attack_speed": 4,
    "minecraft:max_health": 20,
    "minecraft:armor": 0,
    "minecraft:armor_toughness": 0,
    "minecraft:knockback_resistance": 0,
    "minecraft:luck": 0,
};
const ATTRIBUTE_EPSILON = 1e-4;

function hasTamperedAttributes(snapshot: any): boolean {
    const attributes = snapshot?.attributes;
    if (!Array.isArray(attributes)) {
        return false;
    }
    for (const attribute of attributes as SnapshotAttribute[]) {
        if (typeof attribute?.id !== "string" || typeof attribute?.base !== "number") {
            continue;
        }
        const expected = EXPECTED_ATTRIBUTE_BASE[attribute.id];
        if (expected !== undefined && Math.abs(attribute.base - expected) > ATTRIBUTE_EPSILON) {
            return true;
        }
    }
    return false;
}

async function handleSubmit(request: Request, env: Env): Promise<Response> {
    let body: any;
    try {
        body = await request.json();
    } catch {
        return json({ error: "invalid json" }, 400);
    }

    const modpackId = body?.modpack_id;
    const snapshot = body?.snapshot;
    const playerUuid = snapshot?.player_uuid;
    const playerName = snapshot?.player_name;
    const damage = snapshot?.damage;

    if (
        typeof modpackId !== "string" || modpackId.length === 0 ||
        typeof playerUuid !== "string" || playerUuid.length === 0 ||
        typeof playerName !== "string" || playerName.length === 0 ||
        typeof damage !== "number" || !(damage > 0)
    ) {
        return json({ error: "invalid payload" }, 400);
    }

    if (hasTamperedAttributes(snapshot)) {
        return json({ accepted: false, reason: "attribute tampering detected" });
    }

    const modpack = await getModpack(env, modpackId);
    if (!modpack) {
        return json({ accepted: false, reason: "unknown modpack" });
    }
    if (modpack.api_key && request.headers.get("X-Api-Key") !== modpack.api_key) {
        return json({ error: "unauthorized" }, 401);
    }

    const existing = await env.DB.prepare(
        "SELECT damage FROM leaderboard WHERE modpack_id = ?1 AND player_uuid = ?2"
    ).bind(modpackId, playerUuid).first<{ damage: number }>();

    if (existing && existing.damage >= damage) {
        return json({ accepted: false, reason: "not an improvement over your own record" });
    }

    const { results: rivals } = await env.DB.prepare(
        "SELECT damage FROM leaderboard WHERE modpack_id = ?1 AND player_uuid != ?2 ORDER BY damage DESC, created_at ASC LIMIT 10"
    ).bind(modpackId, playerUuid).all<{ damage: number }>();

    const qualifies = rivals.length < 10 || damage > rivals[rivals.length - 1].damage;
    if (!qualifies) {
        return json({ accepted: false, reason: "did not make the top 10" });
    }

    await env.DB.prepare(
        `INSERT INTO leaderboard (modpack_id, player_uuid, player_name, damage, snapshot_json, created_at)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6)
         ON CONFLICT(modpack_id, player_uuid) DO UPDATE SET
             player_name = excluded.player_name,
             damage = excluded.damage,
             snapshot_json = excluded.snapshot_json,
             created_at = excluded.created_at`
    ).bind(modpackId, playerUuid, playerName, damage, JSON.stringify(snapshot), Date.now()).run();

    await env.DB.prepare(
        `DELETE FROM leaderboard WHERE modpack_id = ?1 AND player_uuid NOT IN (
             SELECT player_uuid FROM leaderboard WHERE modpack_id = ?1 ORDER BY damage DESC, created_at ASC LIMIT 10
         )`
    ).bind(modpackId).run();

    return json({ accepted: true });
}
